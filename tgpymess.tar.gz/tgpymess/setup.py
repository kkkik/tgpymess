import setuptools
setuptools.setup(
    name='tgpymess',
    version='0.1',
    author='d9c',
    description='Its works 🤍',
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License"
    ]
)