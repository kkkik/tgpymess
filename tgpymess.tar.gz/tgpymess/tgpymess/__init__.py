from .tgpymess import .send_message
from .tgpymess import .getme